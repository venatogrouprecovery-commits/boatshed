import { createServerClient } from '@supabase/ssr';
import { NextResponse, type NextRequest } from 'next/server';
import { getSupabaseConfig } from './supabase-config';

type CookieToSet = {
  name: string;
  value: string;
  options: any;
};

export async function updateSession(request: NextRequest) {
  const { url, anonKey, configured } = getSupabaseConfig();

  // Never allow middleware to take the whole site down. This keeps the demo
  // visible on Vercel even before Supabase env vars are correctly configured.
  if (!configured || !url || !anonKey) {
    return NextResponse.next({ request });
  }

  let response = NextResponse.next({ request });

  try {
    const supabase = createServerClient(url, anonKey, {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet: CookieToSet[]) {
          cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
          response = NextResponse.next({ request });
          cookiesToSet.forEach(({ name, value, options }) => response.cookies.set(name, value, options));
        }
      }
    });

    await supabase.auth.getUser();
    return response;
  } catch (error) {
    console.error('Supabase middleware skipped:', error);
    return NextResponse.next({ request });
  }
}
